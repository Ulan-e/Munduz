package com.ulan.app.munduz.listeners

interface OnCategoryClickListener {

    fun onCategoryClick(category: String)

}