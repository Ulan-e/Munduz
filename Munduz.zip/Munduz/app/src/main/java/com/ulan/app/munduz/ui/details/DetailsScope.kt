package com.ulan.app.munduz.ui.details

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class DetailsScope