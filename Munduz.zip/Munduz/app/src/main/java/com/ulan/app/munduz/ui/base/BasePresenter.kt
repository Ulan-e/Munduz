package com.ulan.app.munduz.ui.base

interface BasePresenter {

    fun setToolbar()
    fun detachView()
}