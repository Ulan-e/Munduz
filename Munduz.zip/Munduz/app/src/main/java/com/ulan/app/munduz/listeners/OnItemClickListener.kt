package com.ulan.app.munduz.listeners

import com.ulan.app.munduz.developer.Product

interface OnItemClickListener {

    fun onItemClick(product: Product)

}