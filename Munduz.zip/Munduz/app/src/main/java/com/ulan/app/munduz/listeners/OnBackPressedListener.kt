package com.ulan.app.munduz.listeners

interface OnBackPressedListener {

    fun onBackPressed(): Boolean
}