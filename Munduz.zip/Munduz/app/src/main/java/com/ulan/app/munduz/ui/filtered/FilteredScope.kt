package com.ulan.app.munduz.ui.filtered

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class FilteredScope