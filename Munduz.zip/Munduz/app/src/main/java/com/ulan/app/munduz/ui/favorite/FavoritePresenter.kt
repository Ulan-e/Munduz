package com.ulan.app.munduz.ui.favorite

import com.ulan.app.munduz.ui.base.BasePresenter

interface FavoritePresenter : BasePresenter {

    fun loadProducts()

}