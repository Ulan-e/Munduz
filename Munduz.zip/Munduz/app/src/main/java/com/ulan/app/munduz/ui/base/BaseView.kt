package com.ulan.app.munduz.ui.base

interface BaseView {

    fun showToolbar()
    fun showEmptyData()
}