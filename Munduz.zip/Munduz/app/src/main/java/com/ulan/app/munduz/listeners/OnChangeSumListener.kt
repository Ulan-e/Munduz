package com.ulan.app.munduz.listeners

interface OnChangeSumListener {

    fun onSumChanged()

}